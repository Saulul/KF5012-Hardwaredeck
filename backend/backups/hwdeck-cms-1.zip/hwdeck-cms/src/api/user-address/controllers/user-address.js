'use strict';

/**
 *  user-address controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::user-address.user-address');
