'use strict';

/**
 * user-address router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-address.user-address');
