'use strict';

/**
 * user-saved-payment-method router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-saved-payment-method.user-saved-payment-method');
