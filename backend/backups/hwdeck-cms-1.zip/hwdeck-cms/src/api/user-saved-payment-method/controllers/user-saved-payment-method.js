'use strict';

/**
 *  user-saved-payment-method controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::user-saved-payment-method.user-saved-payment-method');
