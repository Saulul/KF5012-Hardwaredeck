'use strict';

/**
 * user-saved-payment-method service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::user-saved-payment-method.user-saved-payment-method');
