'use strict';

/**
 * site-category service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::site-category.site-category');
