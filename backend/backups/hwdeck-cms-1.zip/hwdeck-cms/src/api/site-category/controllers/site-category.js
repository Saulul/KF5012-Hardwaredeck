'use strict';

/**
 *  site-category controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::site-category.site-category');
